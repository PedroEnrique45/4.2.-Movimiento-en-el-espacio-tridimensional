# espacio-tridimensional
4.2. Movimiento en el espacio tridimensional
